# MCP UUID Server

A Model Context Protocol (MCP) server for generating UUIDv7 strings.

## Features

- Get a single UUIDv7 string.
- Get a batch of UUIDv7 strings.

## Installation

To install the MCP UUID Server, you can use pip:

```bash
pip install mcp-uuid-server
```

(Note: This assumes the package will be published to PyPI. For local development, you can run the server directly.)

## Usage

Once installed, you can run the server using the following command:

```bash
mcp-uuid-server
```

The server will start and listen for MCP client connections.

### Available Tools

1.  **`get_uuidv7`**:
    *   Description: Generates and returns a single UUIDv7 string.
    *   Arguments: None
    *   Returns: A string representing a UUIDv7.

2.  **`get_uuidv7_batch`**:
    *   Description: Generates and returns a list of UUIDv7 strings.
    *   Arguments:
        *   `count` (integer): The number of UUIDv7 strings to generate. Must be a positive integer.
    *   Returns: A list of strings, where each string is a UUIDv7.

## Development

To set up the development environment:

1.  Clone the repository.
2.  It's recommended to create and activate a virtual environment:
    ```bash
    python -m venv .venv
    source .venv/bin/activate  # On Windows use `.venv\Scripts\activate`
    ```
3.  Install the dependencies:
    ```bash
    pip install -e .
    ```
    (The `-e .` installs the package in editable mode.)

4.  Run the server directly for testing:
    ```bash
    python mcp_uuid_server/server.py
    ```
    Alternatively, using the installed script (if installed in editable mode):
    ```bash
    mcp-uuid-server
    ```
